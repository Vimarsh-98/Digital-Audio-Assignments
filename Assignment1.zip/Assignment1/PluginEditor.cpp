/*
  ==============================================================================

	This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
A1StarterAudioProcessorEditor::A1StarterAudioProcessorEditor(A1StarterAudioProcessor& p)
	: AudioProcessorEditor(&p), audioProcessor(p)
{
	// Make sure that before the constructor has finished, you've set the
	// editor's size to whatever you need it to be.
	setSize(500, 500);

	// these define the parameters of our slider object
	arpSlider.setSliderStyle(juce::Slider::LinearBarVertical);
	arpSlider.setRange(0.0, 1.0, 0.05);
	arpSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 90, 0);
	arpSlider.setPopupDisplayEnabled(true, false, this);
	arpSlider.setTextValueSuffix(" Speed");
	arpSlider.setValue(0.5);
	
	// this function adds the slider to the editor
	addAndMakeVisible(&arpSlider);
	arpSlider.addListener(this);

	//creates the note duration slider
	noteDurationSlider.setRange(0.50, 4.0, 0.50);
	noteDurationSlider.setValue(0.50);
	noteDurationSlider.setTextValueSuffix("x Duration");
	addAndMakeVisible(noteDurationSlider);
	noteDurationSlider.addListener(this);

	//creates the options for the arpeggiator type combo box
	addAndMakeVisible(&arpType);
	arpType.addItem("Task 1: Ascending Pattern", 1);
	arpType.addItem("Task 1: Descending Pattern", 2);
	arpType.addItem("Task 3(i): Not Ascending or Descending Pattern", 3);
	arpType.addItem("Task 3(ii): Repeated Pattern", 4);
	arpType.addListener(this);

	//creates the options for the number of octaves combo box
	addAndMakeVisible(&numberOfOctaves);
	numberOfOctaves.addItem("Increase by 1 octave", 1);
	numberOfOctaves.addItem("Increase by 2 octaves", 2);
	numberOfOctaves.addItem("Increase by 3 octaves", 3);
	numberOfOctaves.addItem("Increase by 4 octaves", 4);
	numberOfOctaves.addListener(this);
}

A1StarterAudioProcessorEditor::~A1StarterAudioProcessorEditor()
{
}

//==============================================================================
//==============================================================================
//==============================================================================
void A1StarterAudioProcessorEditor::paint(juce::Graphics& g)
{
	// fill the whole window white
	g.fillAll(juce::Colours::darkgrey);

	// set the current drawing colour to black
	g.setColour(juce::Colours::black);

	// set the font size and draw text to the screen
	g.setFont(14.0f);

	// created all the text shown on screen
	g.drawFittedText("Select Arpeggiator Type", 0, 0, getWidth(), 30, juce::Justification::centred, 1);
	g.drawFittedText("Select Number of Octaves", 0, 70, getWidth(), 30, juce::Justification::centred, 1);
	g.drawFittedText("Select Duration of Keys", 0, 140, getWidth(), 30, juce::Justification::centred, 1);
	g.drawFittedText("Adjust", 13, getHeight() - 65, getWidth(), 30, juce::Justification::bottomLeft, 1);
	g.drawFittedText("Speed", 13, getHeight()-50, getWidth(), 30, juce::Justification::bottomLeft, 1);
}

void A1StarterAudioProcessorEditor::resized()
{
	// This is generally where you'll want to lay out the positions of any
	// subcomponents in your editor..
	// sets the position and size of the slider with arguments (x, y, width, height)
	arpSlider.setBounds(20, 40, 20, getHeight() - 90);
	noteDurationSlider.setBounds(100, 170, getWidth() - 200, 35);
	arpType.setBounds(100, 30, getWidth() - 200, 35);
	numberOfOctaves.setBounds(100, 100, getWidth() - 200, 35);
}

void A1StarterAudioProcessorEditor::sliderValueChanged(juce::Slider* slider)
{
	audioProcessor.arpSpeed = arpSlider.getValue();
	audioProcessor.keyDuration = noteDurationSlider.getValue();
}


void A1StarterAudioProcessorEditor::comboBoxChanged(juce::ComboBox* combobox)
{
	audioProcessor.arpMode = arpType.getSelectedId();
	audioProcessor.octave = numberOfOctaves.getSelectedId();

}





