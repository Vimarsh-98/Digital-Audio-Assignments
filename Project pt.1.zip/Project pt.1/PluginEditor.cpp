/*
  ==============================================================================

	This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
A2StarterAudioProcessorEditor::A2StarterAudioProcessorEditor(A2StarterAudioProcessor& p)
	: AudioProcessorEditor(&p), audioProcessor(p)
{
	// Make sure that before the constructor has finished, you've set the
	// editor's size to whatever you need it to be.
	setSize(500, 500);

	// these define the parameters of our slider object
	//volumeSlider.setSliderStyle(juce::Slider::LinearBarVertical);
	volumeSlider.setRange(0.0, 100, 1);
	//volumeSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 90, 0);
	//volumeSlider.setPopupDisplayEnabled(true, false, this);
	volumeSlider.setTextValueSuffix("x");
	volumeSlider.setValue(100);
	addAndMakeVisible(&volumeSlider);
	volumeSlider.addListener(this);

	addAndMakeVisible(volumeLabel);
	volumeLabel.setText("Dry Volume Slider:", juce::dontSendNotification);
	volumeLabel.attachToComponent(&volumeSlider, true);
	volumeLabel.setColour(juce::Label::textColourId, juce::Colours::orange);
	volumeLabel.setJustificationType(juce::Justification::right);

	//Time interval slider: The amount of time between an incoming sound and its first repetition (Task 1 of assignment 2)
	timeIntSlider.setRange(0.0, 3.0, 0.5);
	timeIntSlider.setValue(0.0);
	timeIntSlider.setTextValueSuffix("x");
	addAndMakeVisible(timeIntSlider);
	timeIntSlider.addListener(this);

	addAndMakeVisible(timeIntLabel);
	timeIntLabel.setText("Time Interval Slider:", juce::dontSendNotification);
	timeIntLabel.attachToComponent(&timeIntSlider, true);
	timeIntLabel.setColour(juce::Label::textColourId, juce::Colours::orange);
	timeIntLabel.setJustificationType(juce::Justification::right);

	//Dry slider: The loudness of the incoming signal expressed as a percentage (Task 2 of assignment 2)
	drySlider.setRange(0.0, 100.0, 1.0);
	drySlider.setValue(0.50);
	drySlider.setTextValueSuffix("%");
	addAndMakeVisible(drySlider);
	drySlider.addListener(this);

	addAndMakeVisible(dryLabel);
	dryLabel.setText("Dry Slider:", juce::dontSendNotification);
	dryLabel.attachToComponent(&drySlider, true);
	dryLabel.setColour(juce::Label::textColourId, juce::Colours::orange);
	dryLabel.setJustificationType(juce::Justification::right);

	//Wet slider: The loudness of the repeated sounds expressed as a percentage (Task 3 of assignment 2)
	wetSlider.setRange(0.0, 100.0, 1.0);
	wetSlider.setValue(0.50);
	wetSlider.setTextValueSuffix("%");
	addAndMakeVisible(wetSlider);
	wetSlider.addListener(this);

	addAndMakeVisible(wetLabel);
	wetLabel.setText("Wet Slider:", juce::dontSendNotification);
	wetLabel.attachToComponent(&wetSlider, true);
	wetLabel.setColour(juce::Label::textColourId, juce::Colours::orange);
	wetLabel.setJustificationType(juce::Justification::right);

	//Feedback slider: The amount that each repetition gets fed back into the delay (Task 4 of assignment 2)
	feedBackSlider.setRange(0.0, 100.0, 1.0);
	feedBackSlider.setValue(0.50);
	feedBackSlider.setTextValueSuffix("%");
	addAndMakeVisible(feedBackSlider);
	feedBackSlider.addListener(this);

	addAndMakeVisible(feedBackLabel);
	feedBackLabel.setText("Feedback Slider:", juce::dontSendNotification);
	feedBackLabel.attachToComponent(&feedBackSlider, true);
	feedBackLabel.setColour(juce::Label::textColourId, juce::Colours::orange);
	feedBackLabel.setJustificationType(juce::Justification::right);

	addAndMakeVisible(pingPongOn);


	addAndMakeVisible(pingPongOff);
	pingPongOff.setClickingTogglesState(true);
	//pingPongOn.onClick = [this] { updateToggleState(&pingPongOn, "On");   };


	addAndMakeVisible(pingPongLabel);
	//pingPongLabel.setText("Ping Pong:", juce::dontSendNotification);
	//pingPongLabel.attachToComponent(&pingPongOn, true);
	pingPongLabel.setColour(juce::Label::textColourId, juce::Colours::orange);
	pingPongLabel.setJustificationType(juce::Justification::right);







}

A2StarterAudioProcessorEditor::~A2StarterAudioProcessorEditor()
{
}

//==============================================================================
void A2StarterAudioProcessorEditor::paint(juce::Graphics& g)
{
	// fill the whole window white
	g.fillAll(juce::Colours::darkgrey);

	// set the current drawing colour to black
	g.setColour(juce::Colours::orange);

	// set the font size and draw text to the screen
	g.setFont(25.0f);

	g.drawFittedText("Assignment 2 Delay", 0, 0, getWidth(), 30, juce::Justification::centred, 1);

}

void A2StarterAudioProcessorEditor::resized()
{
	// This is generally where you'll want to lay out the positions of any
	// subcomponents in your editor..
	// sets the position and size of the slider with arguments (x, y, width, height)
	volumeSlider.setBounds(100, 55, getHeight() - 115, 35);
	timeIntSlider.setBounds(100, 125, getWidth() - 115, 35);
	drySlider.setBounds(100, 195, getWidth() - 115, 35);
	wetSlider.setBounds(100, 265, getWidth() - 115, 35);
	feedBackSlider.setBounds(100, 335, getHeight() - 115, 35);
	pingPongOn.setBounds(80, 405, getHeight() - 115, 35);
	pingPongOff.setBounds(100, 405, getHeight() - 115, 35);

}

void A2StarterAudioProcessorEditor::sliderValueChanged(juce::Slider* slider)
{
	audioProcessor.volumeBoost = volumeSlider.getValue();
	audioProcessor.wetBoost = wetSlider.getValue();
	audioProcessor.delayIntTime = timeIntSlider.getValue();
}
