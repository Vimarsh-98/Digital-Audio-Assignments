/*
  ==============================================================================
    This file contains the basic framework code for a JUCE plugin editor.
  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
A3AudioProcessorEditor::A3AudioProcessorEditor(A3AudioProcessor& p)
    : AudioProcessorEditor(&p), audioProcessor(p)
{
    setSize(375, 700);
    addAndMakeVisible(&openButton);
    openButton.onClick = [this] {buttonClicked(); };

    selectImpulse.setJustificationType(juce::Justification::centred);
    selectImpulse.addItem("Impulse: Off", 1);
    selectImpulse.addItem("Discovery Room", 2);
    selectImpulse.addItem("Cathedral Room", 3);
    selectImpulse.addItem("Drainage Tunnel", 4);
    selectImpulse.addItem("Inside A Theatre", 5);
    selectImpulse.addItem("Stairs Leading To Transit", 6);
    selectImpulse.addItem("User Selected Impulse", 7);
    addAndMakeVisible(&selectImpulse);

    selectReverb.setJustificationType(juce::Justification::centred);
    selectReverb.addItem("No Reverb", 1);
    selectReverb.addItem("Reverb 1 (Preset Basic Reverb: Adjust Dry, Wet, Room size or Width Sliders)", 2);
    selectReverb.addItem("Reverb 2 (Select an Impulse below: Impulses only work when Reverb 2 is selected)", 3);
    selectReverb.addItem("Reverb 3 (Constructed Reverb)", 4);
    selectReverb.addItem("Reverb 4 (Delayed Reverb)", 5);
    addAndMakeVisible(&selectReverb);

    wet.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
    wet.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    wet.setPopupDisplayEnabled(true, true, this);
    addAndMakeVisible(&wet);

    wetLabel.setText("Wet Slider                                          (Reverb 1):", juce::dontSendNotification);
    wetLabel.attachToComponent(&wet, true);
    wetLabel.setColour(juce::Label::textColourId, juce::Colours::black);
    wetLabel.setJustificationType(juce::Justification::right);
    addAndMakeVisible(&wetLabel);

    dry.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
    dry.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    dry.setPopupDisplayEnabled(true, true, this);
    addAndMakeVisible(&dry);

    dryLabel.setText("Dry Slider                             (Reverb 1):", juce::dontSendNotification);
    dryLabel.attachToComponent(&dry, true);
    dryLabel.setColour(juce::Label::textColourId, juce::Colours::black);
    dryLabel.setJustificationType(juce::Justification::right);
    addAndMakeVisible(&dryLabel);

    roomSize.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
    roomSize.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    roomSize.setPopupDisplayEnabled(true, true, this);
    addAndMakeVisible(&roomSize);

    roomSizeLabel.setText("Room Size Slider             (Reverb 1):", juce::dontSendNotification);
    roomSizeLabel.attachToComponent(&roomSize, true);
    roomSizeLabel.setColour(juce::Label::textColourId, juce::Colours::black);
    roomSizeLabel.setJustificationType(juce::Justification::right);
    addAndMakeVisible(&roomSizeLabel);

    width.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
    width.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    width.setPopupDisplayEnabled(true, true, this);
    addAndMakeVisible(&width);

    widthLabel.setText("Width Slider                           (Reverb 1):", juce::dontSendNotification);
    widthLabel.attachToComponent(&width, true);
    widthLabel.setColour(juce::Label::textColourId, juce::Colours::black);
    widthLabel.setJustificationType(juce::Justification::right);
    addAndMakeVisible(&widthLabel);

    constructedImpulse.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
    constructedImpulse.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    constructedImpulse.setPopupDisplayEnabled(true, true, this);
    addAndMakeVisible(&constructedImpulse);

    cImpulseLabel.setText("Constructed Impulse                           (Reverb 3):", juce::dontSendNotification);
    cImpulseLabel.attachToComponent(&constructedImpulse, true);
    cImpulseLabel.setColour(juce::Label::textColourId, juce::Colours::white);
    cImpulseLabel.setJustificationType(juce::Justification::right);
    addAndMakeVisible(&cImpulseLabel);

    cutOffSlider.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
    cutOffSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    cutOffSlider.setPopupDisplayEnabled(true, true, this);
    addAndMakeVisible(&cutOffSlider);

    cutofLabel.setText("Cut Off Slider (Reverb 4):", juce::dontSendNotification);
    cutofLabel.attachToComponent(&cutOffSlider, true);
    cutofLabel.setColour(juce::Label::textColourId, juce::Colours::orange);
    cutofLabel.setJustificationType(juce::Justification::right);
    addAndMakeVisible(&cutofLabel);

    delay.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
    delay.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    delay.setPopupDisplayEnabled(true, true, this);
    addAndMakeVisible(&delay);

    delayLabel.setText("Delay Slider (Reverb 4):", juce::dontSendNotification);
    delayLabel.attachToComponent(&delay, true);
    delayLabel.setColour(juce::Label::textColourId, juce::Colours::orange);
    delayLabel.setJustificationType(juce::Justification::right);
    addAndMakeVisible(&delayLabel);

    cutOffValue = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "CUTOFF", cutOffSlider);
    dryValue = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "DRY", dry);
    roomSizeValue = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "ROOMSIZE", roomSize);
    wetValue = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "WET", wet);
    widthValue = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "WIDTH", width);
    delayValue = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "DELAY", delay);
    irValue = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(audioProcessor.apvts, "IR", constructedImpulse);
    buttonValue = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(audioProcessor.apvts, "BUTTON", openButton);
    impulseValue = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(audioProcessor.apvts, "IMPULSE", selectImpulse);
    reverbValue = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(audioProcessor.apvts, "REVERB", selectReverb);
}

void A3AudioProcessorEditor::buttonClicked() {

    juce::FileChooser chooser("Select a Wave file to play...", juce::File::getSpecialLocation(juce::File::userHomeDirectory), "*.wav");

    if (chooser.browseForFileToOpen()) {
        auto ufile = chooser.getResult();
        audioProcessor.selectedFile = ufile;
        selectImpulse.setSelectedId(7);
    }
}

A3AudioProcessorEditor::~A3AudioProcessorEditor()
{
}

//==============================================================================
void A3AudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colours::grey);
    g.setColour(juce::Colours::darkblue);
}

void A3AudioProcessorEditor::resized()
{
    juce::Rectangle<int> area = getLocalBounds().reduced(10);
    juce::Rectangle<int> menus = area.removeFromTop(20);
    selectReverb.setBounds(35, 30, 295, 30);
    selectImpulse.setBounds(35, 80, 145, 30);
    openButton.setBounds(180, 80, 145, 30);
    dry.setBounds(115, 110, 220, 100);
    wet.setBounds(115, 190, 220, 100);
    roomSize.setBounds(115, 270, 220, 100);
    width.setBounds(115, 350, 220, 100);
    constructedImpulse.setBounds(115, 430, 220, 100);
    cutOffSlider.setBounds(115, 510, 220, 100);
    delay.setBounds(115, 590, 220, 100);

}

