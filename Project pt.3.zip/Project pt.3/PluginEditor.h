/*
  ==============================================================================
    This file contains the basic framework code for a JUCE plugin editor.
  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

//==============================================================================
/**
*/
class A3AudioProcessorEditor : public juce::AudioProcessorEditor
{
public:
    A3AudioProcessorEditor(A3AudioProcessor&);
    ~A3AudioProcessorEditor() override;

    //==============================================================================
    void paint(juce::Graphics&) override;
    void resized() override;

private:
    // This reference is provided as a quick way for your editor to
    // access the processor object that created it.
    A3AudioProcessor& audioProcessor;

    juce::Label dryLabel, wetLabel, roomSizeLabel, widthLabel, cutofLabel, delayLabel, cImpulseLabel;

    juce::Slider cutOffSlider;
    juce::Slider rateSlider;
    juce::Slider depthSlider;
    juce::Slider gainSlider;
    juce::Slider wet, dry, roomSize, width, delay, constructedImpulse;

    juce::ComboBox selectReverb;
    juce::ComboBox selectImpulse;

    juce::TextButton openButton{ "Select File to Open:" };

    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> cutOffValue;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> rateValue;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> depthValue;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> gainValue;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> wetValue;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> dryValue;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> roomSizeValue;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> widthValue;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> delayValue;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> irValue;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> reverbValue;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> impulseValue;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> buttonValue;

    void buttonClicked();


    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(A3AudioProcessorEditor)
};