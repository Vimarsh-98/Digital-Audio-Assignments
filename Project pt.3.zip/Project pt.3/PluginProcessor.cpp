/*
  ==============================================================================
    This file contains the basic framework code for a JUCE plugin processor.
  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "DSPDelayLineTutorial_02.h"

//==============================================================================
A3AudioProcessor::A3AudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
    : AudioProcessor(BusesProperties()
#if ! JucePlugin_IsMidiEffect
#if ! JucePlugin_IsSynth
        .withInput("Input", juce::AudioChannelSet::stereo(), true)
#endif
        .withOutput("Output", juce::AudioChannelSet::stereo(), true)
#endif
    ), apvts(*this, nullptr, "PARAMETERS", createParameterLayout())
#endif
{
}

A3AudioProcessor::~A3AudioProcessor()
{
}

//==============================================================================
const juce::String A3AudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool A3AudioProcessor::acceptsMidi() const
{
#if JucePlugin_WantsMidiInput
    return true;
#else
    return false;
#endif
}

bool A3AudioProcessor::producesMidi() const
{
#if JucePlugin_ProducesMidiOutput
    return true;
#else
    return false;
#endif
}

bool A3AudioProcessor::isMidiEffect() const
{
#if JucePlugin_IsMidiEffect
    return true;
#else
    return false;
#endif
}

double A3AudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int A3AudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int A3AudioProcessor::getCurrentProgram()
{
    return 0;
}

void A3AudioProcessor::setCurrentProgram(int index)
{
}

const juce::String A3AudioProcessor::getProgramName(int index)
{
    return {};
}

void A3AudioProcessor::changeProgramName(int index, const juce::String& newName)
{
}

//==============================================================================
void A3AudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{

    juce::dsp::ProcessSpec spec;
    spec.sampleRate = sampleRate;
    spec.maximumBlockSize = samplesPerBlock;
    spec.numChannels = getMainBusNumOutputChannels();
    stateVariableFilter.reset();
    stateVariableFilter.prepare(spec);
    chain.reset();
    chain.prepare(spec);
    outBuffer.setSize(2, samplesPerBlock);
    outBuffer.clear();
    samR = sampleRate;
    samB = samplesPerBlock;
    updateFX();
}

void A3AudioProcessor::updateFX()
{
    float phaserRate = *apvts.getRawParameterValue("PHASERRATE");
    float phaserDepth = *apvts.getRawParameterValue("PHASERDEPTH");
    float gain = *apvts.getRawParameterValue("GAIN");

    int impulseVal = *apvts.getRawParameterValue("IMPULSE");
    int reverbVal = *apvts.getRawParameterValue("REVERB");
    float cutoff = *apvts.getRawParameterValue("CUTOFF");
    float dryVal = *apvts.getRawParameterValue("DRY");
    float wetVal = *apvts.getRawParameterValue("WET");
    float roomVal = *apvts.getRawParameterValue("ROOMSIZE");
    float widthVal = *apvts.getRawParameterValue("WIDTH");
    float delayVal = *apvts.getRawParameterValue("DELAY");
    float irVal = *apvts.getRawParameterValue("IR");

    bypassFilter = false;


    auto& gainProcessor = chain.template get<gainIndex>();
    gainProcessor.setGainLinear(gain);

    auto& phaserProcessor = chain.template get<phaserIndex>();
    phaserProcessor.setRate(phaserRate);
    phaserProcessor.setDepth(phaserDepth);
    auto& revarbParameters = juce::dsp::Reverb::Parameters();
    auto& reverb = chain.template get<reverbIndex>();

    auto& convolution = chain.template get<convoIndex>();

    juce::File desktop;
    juce::File impulseFile;

    if (reverbVal == 2) {

        revarbParameters.dryLevel = dryVal;
        revarbParameters.wetLevel = wetVal;
        revarbParameters.roomSize = roomVal;
        revarbParameters.width = widthVal;
        reverb.setParameters(revarbParameters);
    }
    if (reverbVal == 3) {
        if (impulseVal == 2) impulseFile = desktop.getSpecialLocation(desktop.userDesktopDirectory).getChildFile("Resources").getChildFile("DiscoveryRoom.wav");
        if (impulseVal == 3) impulseFile = desktop.getSpecialLocation(desktop.userDesktopDirectory).getChildFile("Resources").getChildFile("CathedralRoom.wav");
        if (impulseVal == 4) impulseFile = desktop.getSpecialLocation(desktop.userDesktopDirectory).getChildFile("Resources").getChildFile("DrainageTunnel.wav");
        if (impulseVal == 5) impulseFile = desktop.getSpecialLocation(desktop.userDesktopDirectory).getChildFile("Resources").getChildFile("MillsGreekTheater.wav");
        if (impulseVal == 6) impulseFile = desktop.getSpecialLocation(desktop.userDesktopDirectory).getChildFile("Resources").getChildFile("TransitCenter.wav");
        if (impulseVal == 7) impulseFile = selectedFile;

        if (impulseFile.exists()) {
            convolution.reset();
            convolution.loadImpulseResponse(impulseFile, juce::dsp::Convolution::Stereo::yes, juce::dsp::Convolution::Trim::no, 0);
        }
    }

}

void A3AudioProcessor::updateParameters()
{
}
void A3AudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool A3AudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
#if JucePlugin_IsMidiEffect
    juce::ignoreUnused(layouts);
    return true;
#else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
        && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
#if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
#endif

    return true;
#endif
}
#endif

void A3AudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    auto totalNumInputChannels = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();
    int inputNumSamples = buffer.getNumSamples();
    int outputNumSamples = outBuffer.getNumSamples();
    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear(i, 0, buffer.getNumSamples());

    updateFX();
    juce::dsp::AudioBlock<float> block(buffer);
    juce::dsp::AudioBlock<float> outPut(outBuffer);
    juce::dsp::ProcessContextReplacing<float> context(block);
    juce::dsp::ProcessContextNonReplacing<float> context1(block, outPut);

    if (!bypassFilter) stateVariableFilter.process(context);
    if (!bypassPhaser) chain.process(context);

    if (reverbValue == 2) {
        chain.template get<reverbIndex>().process(context);
    }
    if (reverbValue == 3) {
        chain.template get<convoIndex>().process(context);
        for (int i = 0; i < totalNumInputChannels; i++) {
            buffer.addFrom(i, 0, context1.getOutputBlock().getChannelPointer(i), inputNumSamples);
        }
    }
    if (reverbValue == 4) {
        auto eul = juce::MathConstants<float>::euler;
        auto& convolution = chain.template get<convoIndex>();
        float randomVal;
        float exp;
        for (auto i = 0; i < getTotalNumInputChannels(); ++i) {
            float* data = inBuffer.getWritePointer(i);
            for (int i = 0; i < inBuffer.getNumSamples(); ++i) {
                randomVal = (float)(rand() % 10000) * 0.0001f;
                exp = (float)(decay * i) / (float)(impulseLength * (inBuffer.getNumSamples()));
                data[i] = pow(eul, exp);
                data[i] *= randomVal;
            }
        }
        convolution.loadImpulseResponse(juce::AudioBuffer<float>(inBuffer), samR, juce::dsp::Convolution::Stereo::yes, juce::dsp::Convolution::Trim::no, juce::dsp::Convolution::Normalise::no);
        constructedReverb = false;
    }

    write += inputNumSamples;
    write %= outputNumSamples;
}

//==============================================================================
bool A3AudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* A3AudioProcessor::createEditor()
{
    return new A3AudioProcessorEditor(*this);
}

//==============================================================================
void A3AudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    // You should use this method to store your parameters in the memory block.
    // You could do that either as raw data, or use the XML or ValueTree classes
    // as intermediaries to make it easy to save and load complex data.
}

void A3AudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    // You should use this method to restore your parameters from this memory block,
    // whose contents will have been created by the getStateInformation() call.
}

//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new A3AudioProcessor();
}

juce::AudioProcessorValueTreeState::ParameterLayout A3AudioProcessor::createParameterLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout layout;

    layout.add(std::make_unique<juce::AudioParameterFloat>("CUTOFF", "Cutoff", 20.0f, 20000.0f, 600.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>("PHASERRATE", "Rate", 0.0f, 2.0f, 1.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>("PHASERDEPTH", "Depth", 0.0f, 1.0f, 0.5f));
    layout.add(std::make_unique<juce::AudioParameterFloat>("GAIN", "Gain", 0.0f, 2.0f, 1.0f));
    layout.add(std::make_unique<juce::AudioParameterInt>("FILTERMENU", "Filter Menu", 1, 4, 4));
    layout.add(std::make_unique<juce::AudioParameterInt>("PHASERMENU", "Phaser Menu", 1, 2, 2));
    layout.add(std::make_unique<juce::AudioParameterInt>("IMPULSE", "Impulse Menu", 1, 7, 1));
    layout.add(std::make_unique<juce::AudioParameterInt>("REVERB", "Reverb Menu", 1, 5, 1));
    layout.add(std::make_unique<juce::AudioParameterFloat>("DRY", "Dry", 0.0f, 1.0f, 100.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>("WET", "Wet", 0.0f, 1.0f, 0.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>("WIDTH", "Width", 0.0f, 1.0f, 0.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>("ROOMSIZE", "Room size", 0.0f, 1.0f, 0.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>("DELAY", "Delay", 0.0f, 1.0f, 0.0f));
    layout.add(std::make_unique<juce::AudioParameterFloat>("IR", "Constructed Impulse", 0.0f, 6.0f, 0.0f));
    layout.add(std::make_unique<juce::AudioParameterBool>("BUTTON", "Button", false));

    return layout;
}
